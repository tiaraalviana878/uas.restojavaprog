sthetic Restaurant - JavaFX sample app
---------------------------------------
How to run:
1. Make sure you have Java 17+ installed and JavaFX SDK 25.0.1 downloaded.
2. Open this project in VS Code with Java Extension Pack.
3. Ensure the path in .vscode/launch.json and settings.json points to your javafx-sdk-25.0.1 lib folder.
4. Run the configuration 'Run JavaFX App' or run view.Main from VS Code.
