package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.print.PrinterJob;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.MenuItem;
import model.OrderItem;
import view.MainView;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MainController {
    private MainView view;
    private final ObservableList<OrderItem> cart = FXCollections.observableArrayList();
    private final ObservableList<MenuItem> menu = FXCollections.observableArrayList();

    public MainController() {
        loadSampleMenu();
    }

    public void setView(MainView view) {
        this.view = view;
        view.bindMenu(menu);
        view.bindCart(cart);
    }

    private void loadSampleMenu() {
        menu.addAll(
            new MenuItem("Pasta Carbonara", 45000, "/images/pasta.jpg"),
            new MenuItem("Cheese Burger", 38000, "/images/burger.jpg"),
            new MenuItem("Matcha Latte", 25000, "/images/matcha.jpg"),
            new MenuItem("Fruit Salad", 30000, "/images/salad.jpg")
        );
    }

    public void addToCart(MenuItem item) {
        for (OrderItem oi : cart) {
            if (oi.getName().equals(item.getName())) {
                oi.increment();
                view.refreshCart();
                return;
            }
        }
        cart.add(new OrderItem(item));
        view.refreshCart();
    }

    public void removeOne(OrderItem orderItem) {
        orderItem.decrement();
        if (orderItem.getQuantity() <= 0) cart.remove(orderItem);
        view.refreshCart();
    }

    public int computeTotal() {
        return cart.stream().mapToInt(OrderItem::getTotalPrice).sum();
    }


    // ============================
    //  ✨ FITUR CETAK BILL BARU ✨
    // ============================

    private String buildReceipt() {
        StringBuilder s = new StringBuilder();

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        s.append("4'Restaurant\n");
        s.append("Tanggal: ").append(LocalDateTime.now().format(dtf)).append("\n");
        s.append("--------------------------------\n");

        for (OrderItem oi : cart) {
            s.append(oi.getName())
                    .append(" x")
                    .append(oi.getQuantity())
                    .append("  Rp ")
                    .append(String.format("%,d", oi.getTotalPrice()))
                    .append("\n");
        }

        s.append("--------------------------------\n");
        s.append("Subtotal: Rp ").append(String.format("%,d", computeTotal())).append("\n");

        int tax = (int)(computeTotal() * 0.10);
        int service = (int)(computeTotal() * 0.05);

        s.append("PPN (10%): Rp ").append(String.format("%,d", tax)).append("\n");
        s.append("Service (5%): Rp ").append(String.format("%,d", service)).append("\n");

        int total = computeTotal() + tax + service;
        s.append("TOTAL: Rp ").append(String.format("%,d", total)).append("\n");

        s.append("\nTerima kasih sudah berkunjung!\n");

        return s.toString();
    }

    private void showPrintPreview(String text) {
        Stage stage = new Stage();
        stage.setTitle("Bill Preview");
        stage.initModality(Modality.APPLICATION_MODAL);

        TextArea area = new TextArea(text);
        area.setEditable(false);
        area.setWrapText(true);

        Button printBtn = new Button("Print");
        Button closeBtn = new Button("Close");

        printBtn.setOnAction(e -> {
            printNode(area);
            stage.close();
            showThankYou();
        });

        closeBtn.setOnAction(e -> {
            stage.close();
            showThankYou();
        });

        ToolBar tb = new ToolBar(printBtn, closeBtn);
        BorderPane root = new BorderPane();
        root.setCenter(area);
        root.setBottom(tb);

        stage.setScene(new Scene(root, 400, 500));
        stage.showAndWait();
    }

    private void showThankYou() {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle("Terima Kasih");
        a.setHeaderText(null);
        a.setContentText("Pesanan berhasil! Terima kasih 😊");
        a.showAndWait();
    }

    private void printNode(Node node) {
        PrinterJob job = PrinterJob.createPrinterJob();
        if (job != null && job.showPrintDialog(node.getScene().getWindow())) {
            job.printPage(node);
            job.endJob();
        }
    }


    // ============================
    //  🚀 OVERRIDE confirmOrder()
    // ============================

    public void confirmOrder() {
        if (cart.isEmpty()) {
            view.showMessage("Keranjang kosong", "Silakan pilih menu terlebih dahulu.");
            return;
        }

        String receipt = buildReceipt();

        showPrintPreview(receipt);  // tampilkan bill + print

        cart.clear();
        view.refreshCart();
    }
}
