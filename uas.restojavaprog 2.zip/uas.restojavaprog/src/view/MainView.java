package view;

import controller.MainController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import model.MenuItem;
import model.OrderItem;

public class MainView extends BorderPane {
    private final ListView<MenuItem> menuList = new ListView<>();
    private final ListView<OrderItem> cartList = new ListView<>();
    private final Label totalLabel = new Label("Rp 0");

    // Tambahan
    private final Label taxLabel = new Label("PPN (10%): Rp 0");
    private final Label serviceLabel = new Label("Service (5%): Rp 0");
    private final ComboBox<String> paymentMethod = new ComboBox<>();
    private final TextField cashInput = new TextField();
    private final Label changeLabel = new Label("Kembalian: Rp 0");

    private final MainController controller;

    public MainView(MainController controller) {
        this.controller = controller;
        buildLayout();
    }

    private void buildLayout() {
        // Header
        Label title = new Label("4'Restaurant");
        title.getStyleClass().add("title");
        StackPane header = new StackPane(title);
        header.setPadding(new Insets(20));
        header.setStyle("-fx-background-color: linear-gradient(#fff7ec, #95ab97ff);");
        setTop(header);

        // Menu list
        menuList.setCellFactory(lv -> new view.MenuCell(controller));
        menuList.setPrefWidth(680);

        VBox leftBox = new VBox(12, new Label("Menu"), menuList);
        leftBox.setPadding(new Insets(20));

        // Cart
        cartList.setCellFactory(lv -> new view.CartCell(controller));
        cartList.setPrefWidth(320);

        Label cartTitle = new Label("Order Summary");
        cartTitle.getStyleClass().add("title-small");

        // Payment UI
        paymentMethod.getItems().addAll("Cash", "QRIS", "Debit");
        paymentMethod.setValue("Cash");

        cashInput.setPromptText("Masukkan uang cash");
        cashInput.setDisable(false);

        paymentMethod.setOnAction(e -> {
            boolean isCash = paymentMethod.getValue().equals("Cash");
            cashInput.setDisable(!isCash);
            if (!isCash) {
                cashInput.clear();
                changeLabel.setText("Kembalian: Rp 0");
            }
        });

        cashInput.textProperty().addListener((obs, oldVal, newVal) -> updateChange());

        Button confirm = new Button("Confirm Order");
        confirm.getStyleClass().add("confirm-button");
        confirm.setOnAction(e -> controller.confirmOrder());

        HBox totalRow = new HBox(10, new Label("Total:"), totalLabel, confirm);
        totalRow.setAlignment(Pos.CENTER_LEFT);
        totalRow.setPadding(new Insets(10));

        VBox rightBox = new VBox(
                12,
                cartTitle,
                cartList,

                taxLabel,
                serviceLabel,
                paymentMethod,
                cashInput,
                changeLabel,

                totalRow
        );

        rightBox.setPadding(new Insets(20));
        rightBox.setStyle("-fx-background-color: transparent;");

        HBox main = new HBox(leftBox, rightBox);
        HBox.setHgrow(leftBox, Priority.ALWAYS);
        setCenter(main);
    }

    public void bindMenu(javafx.collections.ObservableList<MenuItem> items) {
        menuList.setItems(items);
    }

    public void bindCart(javafx.collections.ObservableList<OrderItem> items) {
        cartList.setItems(items);
    }

    // TOTAL BARU = subtotal + ppn + service
    public void setTotal(int subtotal) {
        int tax = (int) (subtotal * 0.10);
        int service = (int) (subtotal * 0.05);
        int finalTotal = subtotal + tax + service;

        taxLabel.setText("PPN (10%): Rp " + format(tax));
        serviceLabel.setText("Service (5%): Rp " + format(service));
        totalLabel.setText("Rp " + format(finalTotal));

        updateChange();
    }

    private void updateChange() {
        if (!paymentMethod.getValue().equals("Cash")) {
            changeLabel.setText("Kembalian: Rp 0");
            return;
        }

        int total = controller.computeTotal();
        int tax = (int) (total * 0.10);
        int service = (int) (total * 0.05);
        int finalTotal = total + tax + service;

        try {
            int cash = Integer.parseInt(cashInput.getText());
            int change = cash - finalTotal;
            changeLabel.setText("Kembalian: Rp " + format(Math.max(change, 0)));
        } catch (Exception e) {
            changeLabel.setText("Kembalian: Rp 0");
        }
    }

    public void refreshCart() {
        setTotal(controller.computeTotal());
        cartList.refresh();
    }

    public void updateCart() {
        refreshCart();
    }

    public void showMessage(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle(title);
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }

    private String format(int num) {
        return String.format("%,d", num);
    }
}
