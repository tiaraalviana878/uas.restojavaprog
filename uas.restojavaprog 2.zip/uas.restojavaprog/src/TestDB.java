import database.Database;

public class TestDB {
    public static void main(String[] args) {
        Database.connect();
    }
}
